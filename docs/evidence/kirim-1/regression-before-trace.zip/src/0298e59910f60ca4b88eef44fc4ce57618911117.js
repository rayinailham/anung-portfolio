import { test, expect } from '@playwright/test';

async function ready(page, route = '/') {
  await page.goto(`/#${route}`);
  await expect(page.locator('.splash')).toHaveCount(0);
  await expect(page.locator('.app')).not.toHaveAttribute('inert');
}

test('filter layout refresh reveals organizations, every card and contact callout', async ({ page }) => {
  await ready(page, '/pengalaman');
  // Let the initial refresh finish before changing the document height.
  await page.waitForTimeout(350);
  await page.getByRole('button', { name: 'Pemasaran digital', exact: true }).click();
  await expect(page.locator('.experience-card')).toHaveCount(1);
  await page.locator('.organizations').evaluate(el => el.scrollIntoView({ block: 'start' }));
  await expect(page.locator('.organizations')).toHaveCSS('opacity', '1', { timeout: 2000 });
  for (const card of await page.locator('.organization-grid > article').all()) {
    await card.scrollIntoViewIfNeeded();
    await expect(card).toHaveCSS('opacity', '1', { timeout: 2000 });
  }
  await page.locator('.contact-callout').scrollIntoViewIfNeeded();
  await expect(page.locator('.contact-callout')).toHaveCSS('opacity', '1', { timeout: 2000 });
});

test('intro completes; route transition, back and deep links work', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await ready(page);
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Halo, saya');
  await page.getByRole('link', { name: 'Lihat pengalaman', exact: true }).click();
  await expect(page.locator('.app')).not.toHaveAttribute('inert');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('magang saya.');
  await expect(page.locator('main')).toBeFocused();
  await page.goBack();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Halo, saya');
  await page.goForward();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('magang saya.');
  await ready(page, '/tentang');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('saya Anung.');
  expect(errors).toEqual([]);
});

test('experience filters and contribution disclosures work', async ({ page }) => {
  await ready(page, '/pengalaman');
  await expect(page.locator('.experience-card')).toHaveCount(3);
  await page.getByRole('button', { name: 'Kerja sama KOL', exact: true }).click();
  await expect(page.locator('.experience-card')).toHaveCount(1);
  await page.getByRole('button', { name: 'Lihat detail' }).click();
  await expect(page.locator('.experience-details:visible')).toContainText('100 mitra afiliasi Shopee');
  await page.getByRole('button', { name: 'Tutup detail' }).click();
  await expect(page.locator('.experience-details')).toBeHidden();
  await page.getByRole('button', { name: 'Semua', exact: true }).click();
  await expect(page.locator('.experience-card')).toHaveCount(3);
});

test('theme persists and CV download contains a PDF', async ({ page, request }) => {
  await ready(page);
  await page.getByRole('button', { name: 'Aktifkan mode gelap' }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  const response = await request.get('/documents/anung-ramadhan-cv.pdf');
  expect(response.status()).toBe(200);
  expect((await response.body()).subarray(0, 5).toString()).toBe('%PDF-');
  await expect(page.getByRole('link', { name: 'Download CV', exact: true })).toHaveAttribute('download', '');
});

test('contact form validates inputs and prepares an honest email handoff', async ({ page }) => {
  await ready(page, '/kontak');
  const mailto = [];
  await page.route('mailto:**', route => { mailto.push(route.request().url()); return route.abort(); });
  await page.getByRole('button', { name: 'Buka draf email', exact: true }).click();
  expect(await page.locator('input[name="name"]').evaluate(el => el.validity.valueMissing)).toBe(true);
  await page.getByLabel('Nama', { exact: true }).fill('Test Portfolio');
  await page.getByLabel('Email', { exact: true }).fill('portfolio@example.com');
  await page.getByLabel('Topik pesan').selectOption('Kerja sama promosi');
  await page.getByLabel('Pesan', { exact: true }).fill('Halo Anung, mari berdiskusi tentang kolaborasi brand.');
  await page.getByRole('button', { name: 'Buka draf email', exact: true }).click();
  await expect(page.locator('.form-status')).toContainText('Draf email siap dibuka');
  await expect(page.getByRole('link', { name: 'anungramadhan17@gmail.com', exact: true })).toHaveAttribute('href', 'mailto:anungramadhan17@gmail.com');
  await expect(page.locator('.form-footer')).toContainText('Untuk mengirim pesan, tekan tombol kirim di aplikasi email.');
});

test('reduced motion bypasses intro and smooth scroll; keyboard navigation works', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await ready(page);
  await expect(page.locator('html')).not.toHaveClass(/lenis/);
  const link = page.getByRole('link', { name: 'Lihat pengalaman', exact: true });
  await link.focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('magang saya.');
  await expect(page.locator('main')).toBeFocused();
});

test('mobile menu supports open, escape and navigation', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await ready(page);
  await expect(page.getByRole('navigation')).toBeHidden();
  await page.getByRole('button', { name: 'Buka menu' }).click();
  await expect(page.getByRole('navigation')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('button', { name: 'Buka menu' })).toBeFocused();
  await page.getByRole('button', { name: 'Buka menu' }).click();
  await page.getByRole('navigation').getByRole('link', { name: 'Kontak', exact: true }).click();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Ada peluang');
  await expect(page.getByRole('navigation')).toBeHidden();
});

test('all pages keep readable text, fit narrow screens and load images in both themes', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.emulateMedia({ reducedMotion: 'reduce' });
  for (const width of [320, 768, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    for (const route of ['/', '/pengalaman', '/tentang', '/kontak']) {
      await ready(page, route);
      await expect(page.locator('h1')).toHaveCount(1);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      const typography = await page.evaluate(() => {
        const walker = document.createTreeWalker(document.querySelector('.app'), NodeFilter.SHOW_TEXT);
        const small = [];
        let checked = 0;
        while (walker.nextNode()) {
          const node = walker.currentNode;
          const element = node.parentElement;
          if (!node.textContent.trim() || element.closest('.sr-only, [aria-hidden="true"], svg') || !element.getClientRects().length) continue;
          checked++;
          if (parseFloat(getComputedStyle(element).fontSize) < 14) small.push(node.textContent.trim());
        }
        return { checked, small };
      });
      expect(typography.checked).toBeGreaterThan(15);
      expect(typography.small).toEqual([]);
      if (route === '/kontak') {
        const inputSizes = await page.locator('input, select, textarea').evaluateAll(elements => elements.map(element => parseFloat(getComputedStyle(element).fontSize)));
        expect(inputSizes.every(size => size >= 16)).toBe(true);
      }
      for (const theme of ['dark', 'light']) {
        await page.evaluate(value => { document.documentElement.dataset.theme = value; }, theme);
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      }
      const images = await page.locator('img:not([loading="lazy"])').evaluateAll(imgs => imgs.every(img => img.complete && img.naturalWidth > 0));
      expect(images).toBe(true);
    }
  }
  expect(errors).toEqual([]);
});

test('unknown route has a usable recovery path', async ({ page }) => {
  await ready(page, '/missing-page');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Sepertinya salah jalan.');
  await page.getByRole('link', { name: 'Kembali ke beranda' }).click();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Halo, saya');
});

test('interrupted transition and live reduced motion never lock the page', async ({ page }) => {
  await ready(page);
  await page.evaluate(() => { location.hash = '/pengalaman'; });
  await expect(page.locator('.app')).toHaveAttribute('inert');
  await page.evaluate(() => { location.hash = '/'; });
  await expect(page.locator('.app')).not.toHaveAttribute('inert');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Halo, saya');
  await page.evaluate(() => { location.hash = '/kontak'; });
  await expect(page.locator('.app')).toHaveAttribute('inert');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await expect(page.locator('.app')).not.toHaveAttribute('inert');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Ada peluang');
  await expect(page.locator('body')).not.toHaveClass(/motion-locked/);
});
